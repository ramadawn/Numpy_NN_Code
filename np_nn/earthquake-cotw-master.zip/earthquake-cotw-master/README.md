# Earthquake-cotw
Response to Siraj Raval's weekly challenge in "How to Do Math Easily - Intro to Deep Learning #4" video

# Dependencies
Only NumPy and Python 3.6 !

# Usage
You can directly run the scripy in terminal <code>python earthquake.py</code>
